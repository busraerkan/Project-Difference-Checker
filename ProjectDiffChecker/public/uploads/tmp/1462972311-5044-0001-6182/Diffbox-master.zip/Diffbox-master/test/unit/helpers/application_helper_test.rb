require 'test_helper'

class ApplicationHelperTest < ActionView::TestCase
end
