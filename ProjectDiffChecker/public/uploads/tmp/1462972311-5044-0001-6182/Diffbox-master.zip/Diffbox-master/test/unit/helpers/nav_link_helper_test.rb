require 'test_helper'

class NavLinkHelperTest < ActionView::TestCase
end
