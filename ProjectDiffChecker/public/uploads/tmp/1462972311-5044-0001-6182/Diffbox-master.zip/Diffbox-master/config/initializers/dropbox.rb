Dropbox::API::Config.app_key    = 'i0fkgf9nz42ese8'
Dropbox::API::Config.app_secret = 'vcm80qmcooklrzl'
Dropbox::API::Config.mode       = 'dropbox'
