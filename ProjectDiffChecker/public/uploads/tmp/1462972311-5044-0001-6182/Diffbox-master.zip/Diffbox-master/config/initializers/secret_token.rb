# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Diffbox::Application.config.secret_token = '0519e71aee5933ff9132d976a9b4cfedc64b7847f491ddca43c1b399c87a8c0788759868e8e936e10a73782089806735b04b909ccc977bfb79271c507e568046'
